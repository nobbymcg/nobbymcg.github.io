// Create a custom page TOC ("mini TOC")

// return the type of heading level it is
function get_header_level(element) {
  if ($(element).is('h1'))
      return 1;

  if ($(element).is('h2'))
      return 2;

  if ($(element).is('h3'))
      return 3;

  //if ($(element).is('h4'))
  //    return 4;

  return null;
}

function generate_toc(headers) {

  var header_level = null;
  var toc_HTML = "";

  Array.from(headers).forEach(header => {

      if (!$(header).attr('id'))
          return;

      // formatting the link appearance
      var current_header_level = get_header_level(header);
      var current_header_text = header.innerText;
      var LINK = '#' + $(header).attr('id');
      var link_url = "<a href=" + LINK + ">" + current_header_text + "</a>";

      if (header_level == null) {
          header_level = current_header_level;
      }

      if (current_header_level > header_level) {
          /// go down a certain number of levels
          // open new lists
          toc_HTML += HTML_UNORDERED_LIST_START.repeat(current_header_level - header_level);
          // add the item to the list
          toc_HTML += HTML_ORDERED_LIST_ITEM_START + link_url + HTML_ORDERED_LIST_ITEM_END;

          header_level = current_header_level;

      } else if (current_header_level < header_level) {
          // done list, go back up a certain number of levels eg: h3 -> h1
          // close the open lists
          toc_HTML += HTML_UNORDERED_LIST_END.repeat(header_level - current_header_level);
          // add the item to the list
          toc_HTML += HTML_ORDERED_LIST_ITEM_START + link_url + HTML_ORDERED_LIST_ITEM_END;

          header_level = current_header_level;

      } else {
          // same level, just add this element to the current list
          // add the item to the list
          toc_HTML += HTML_ORDERED_LIST_ITEM_START + link_url + HTML_ORDERED_LIST_ITEM_END;
      }

    


  });

  // close the ending lists

  for (i = header_level; i > 0; i--) {
    toc_HTML += HTML_UNORDERED_LIST_END;
  }

  // make this compiled list a child of the toc-js
  $('ul.toc-js').append(toc_HTML);

  //return toc_HTML;
} // end of function generate_toc 

var HTML_ORDERED_LIST_ITEM_START = "<li>";
var HTML_ORDERED_LIST_ITEM_END = "</li>";
var HTML_UNORDERED_LIST_START = "<ol>";
var HTML_UNORDERED_LIST_END = "</ol>";

function buildMiniToc() {

  $(window).scroll(function() {
      
      var windScroll = $(this).scrollTop();

      if (windScroll) {

        var contentHeadings = $(".doc-content > h1, h2, h3");

        for (var i = 0; i < contentHeadings.length; i++) {

            //set header to active (bold) depending on window content scroll location for the active link
            if ($(contentHeadings[i]).position().top >= windScroll) {

                var sidebarHeadings = $("#TableOfContents").find('[href="#' + $(contentHeadings[i]).attr('id') + '"]');

                if (sidebarHeadings.length) {

                    //the current link is the active one
                    $("#TableOfContents").find("a").removeClass("active");
                    sidebarHeadings.addClass("active");

                    var activeTOCHeadingToTopOfContainer = sidebarHeadings.offset().top - $('.td-toc').offset().top;

                    if(activeTOCHeadingToTopOfContainer > $('.td-toc').height()) {
                        $('.td-toc').scrollTop(sidebarHeadings.get(0).offsetTop - $('.td-toc').height());
                    }

                    else if(activeTOCHeadingToTopOfContainer < 0) {
                       $('.td-toc').scrollTop(sidebarHeadings.get(0).offsetTop);
                    }
                }
                break;
            }
        }
    }
  }).scroll();

  $(window).resize(function() {
      if ($(window).width() > 1143) {
          $('.mini-toc-header i').removeClass('fa-caret-right').addClass('fa-caret-down');
          $('#TableOfContents').show();
      } else {
          $('.mini-toc-header i').removeClass('fa-caret-down').addClass('fa-caret-right');
          $('#TableOfContents').hide();
      }
  }).resize();

  window.addEventListener("load", (event) => {
      createObserver();
  }, false);

}


// run the function on page load to build the toc
// we must have the page loaded first to know what elements on the page are headers 
window.onload = function() {
  buildMiniToc();

  var page_header_elements = $(".td-content > h1,h2,h3");

  var toc_div = $(".mini-toc-header");

  toc_div.html(generate_toc(page_header_elements));

};